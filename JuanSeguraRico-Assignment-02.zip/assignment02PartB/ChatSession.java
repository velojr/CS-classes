/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: ChatSession.java
 * Author: Juan Segura Rico
 * **********************************************
 */

package assignment02PartB;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class ChatSession {

    //  Static Data Fields

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_PURPLE_BACKGROUND = "\u001B[45m";

    private static final DateTimeFormatter DATE_TIME_FORMATTER
            = DateTimeFormatter.ofPattern("yyyy'/'MM'/'dd HH':'mm':'ss");
    private final String[] messages;
    private String startTime;
    private String endTime;
    private String tmpString;


    //
    // Constructors
    //
    public ChatSession() {
        this.club = new Club();
        this.player = new Player();
        this.clubPrompt = this.club.getShortName() + ": ";
        this.playerPrompt = this.player.toString() + ": ";
        this.student = new Student();
        this.studentPrompt = new String();
        this.messages = new String[17];
        this.quiz = new Quiz();
        this.startTime = new String();
        this.endTime = new String();
        this.logData = new ArrayList();
    }

    public ChatSession(Club club, Player player) {
        this.club = club;
        this.player = player;
        this.clubPrompt = this.club.getShortName() + ": ";
        this.playerPrompt = this.player.toString() + ": ";
        this.student = new Student();
        this.studentPrompt = new String();
        this.messages = new String[17];
        this.quiz = new Quiz();
        this.startTime = new String();
        this.endTime = new String ();
        this.logData = new ArrayList();

    //
    // Instance Methods
    //

    //
    // Additional Instance Methods
    //
    private void startChatSession() {
            this.messages[0] = " Chat session started.";
            this.messages[1] = "\n" + this.club + "Welcome to " + club.getName().toUpperCase() + "!";
            this.messages[2] = "\n" + this.club + "Your first and last name, please: ";
            this.messages[3] = this.club + "Your school email address, please: ";
            this.messages[4] = this.club + "Thank you. Connecting with a SF Giants player";
            this.messages[5] = " Chat session ended.";
        }
    }
    private void connectChatters() {
    }
    private void chat() {
    }
    private void runQuiz() {
    }
    private void stopChatSession() {
        this.endTime = LocalDateTime.now().format(DATE_TIME_FORMATTER);
        System.out.println(this.endTime + this.messages[5]);
        System.out.println();
        // Write Log
        this.logData.add(this.startTime + this.messages[0]);
        this.logData.add(this.player.toString());
        this.logData.add(this.student.toString() + ", " + this.student.getSchoolEmailAddress());
        this.logData.add(Integer.toString(this.student.getCardsSize()));
        for (int i = 0; i < this.student.getCardsSize(); i++) {
            this.logData.add(this.student.getCardsRecipient(i));
            this.logData.add(this.student.getCardsMessage(i));
        }
        if (this.allCorrect == true) {
            this.logData.add(this.messages[15]);
        }
        this.logData.add(this.endTime + this.messages[5]);
    }
    public void runChatSession() {
    }

    //
    // Language
    //
}