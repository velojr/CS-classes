/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Quiz.java
 * Author: Juan Segura Rico
 * **********************************************
 */

package assignment02PartB;

public final class Quiz {

    //
    // Instance Data Fields
    //

    //
    // Constructors
    //
    public Quiz() {
    }

    //
    // Instance Methods
    //

    //
    // Additional Instance Methods
    //

    //
    // Language
    //
}