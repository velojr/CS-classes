/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Person.java
 * Author: Juan Segura Rico
 * **********************************************
 */

package assignment02PartB;

public sealed abstract class Person implements Greeting permits Student, Player, President, GeneralManager, Manager {

    //
    // Instance Data Fields
    //

    private String firstName;
    private String lastName;

    //
    // Constructors
    //
    public Person() {
    }

    public String getFirstName(){
        return this.firstName;
    }

    public String getLastName(){
        return this.lastName;
    }

    public void setFirstName(String firstName){
        this.firstName = firstName;
    }

    public void setLastName(String lastName){
        this.lastName = lastName;
    }


    //
    // @override
    //

    @Override
    public String toString(){
        return "First Name:" + this.getFirstName() + "Last Name:" + this.getLastName();
    }

}