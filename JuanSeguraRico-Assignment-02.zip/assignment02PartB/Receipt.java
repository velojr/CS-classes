/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Receipt.java
 * Author: Juan Segura Rico
 * **********************************************
 */

package assignment02PartB;

public final class Receipt {

    //
    // Static Data Fields
    //

    //
    // Instance Data Fields
    //

    //
    // Constructors
    //
    public Receipt() {
    }

    //
    // Static Methods
    //

    //
    // Instance Methods
    //

    //
    // Additional Methods
    //

    //
    // Language
    //
}