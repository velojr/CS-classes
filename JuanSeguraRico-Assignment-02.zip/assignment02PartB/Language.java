/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Language.java
 * Author: Juan Segura Rico
 * **********************************************
 */

package assignment02PartB;

public final class Language {
    //
    // Static Data Fields
    //    
    private static final String defaultAlienSound = "~ ąļīæń ~ "; // Default

    //
    // Instance Data Fields
    //

    private String language;
    private String GreetingPhrase;

    //
    // Constructors
    //
    public Language() {
    }
    public Language(String language) {

        switch (language.toLowerCase()) {
            case "alien" -> this.populateAlienPhrases();            // Supported
            case "chinese" -> this.populateChinesePhrases();        // Future implementation
            case "french" -> this.populateFrenchPhrases();          // Future implementation
            case "spanish" -> this.populateSpanishPhrases();        // Future implementation
            case "future" -> this.populateYourLanguagePhrases();    // Future implementation
            default -> this.populateEnglishPhrases();               // Supported
        }

    }

    private void populateAlienPhrases() {}
    private void populateChinesePhrases(){}
    private void populateFrenchPhrases(){}
    private void populateSpanishPhrases(){}
    private void populateYourLanguagePhrases(){}
    private void populateEnglishPhrases(){}

    //
    // Static Methods
    //

    //
    // Instance Methods
    //

    //
    // Language
    //
}