/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: President.java
 * Author: Juan Segura Rico
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class President extends Person {

    //
    // Instance Data Fields
    //

    //
    // Constructors
    //
    public President() {
    }

    //
    // Instance Methods
    //

    //
    // Language
    //

    //
    // Override
    //
}
