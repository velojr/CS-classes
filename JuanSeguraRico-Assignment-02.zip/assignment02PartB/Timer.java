/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Timer.java
 * Author: Juan Segura Rico
 * **********************************************
 */

package assignment02PartB;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

public class Timer {

   public Timer() {

      DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

   String timeZone = "PST";
   dateFormat.setTimeZone(TimeZone.getTimeZone("America/San_Francisco"));
   System.out.println(timeZone +": "+dateFormat.format(newDate()));

   timeZone ="CST";
   dateFormat.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
   System.out.println(timeZone +": "+dateFormat.format(newDate()));

   timeZone ="EST";
   dateFormat.setTimeZone(TimeZone.getTimeZone("America/New_York"));
   System.out.println(timeZone +": "+dateFormat.format(newDate()));



   //
    // Static Methods
    //

    //
    // Additional Static Methods
    //

    //
    // Instance Methods
    //

    //
    // Additional Instance Methods
    //

    //
    // Language
    //
}