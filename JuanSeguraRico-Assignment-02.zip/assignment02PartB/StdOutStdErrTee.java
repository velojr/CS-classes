/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: StdOutStdErrTee.java
 * Author: Juan Segura Rico
 * **********************************************
 */

package assignment02PartB;
import java.io.*;
public class StdOutStdErrTee extends OutputStream {

    //
    // Instance Data Fields
    //

    private String stdOutFilePath;
    private String stdErrFilePath;
    private OutputStream[] streamsToConsoleToFile;

    //
    // Constructors
    //

    public StdOutStdErrTee() {

    }

    public StdOutStdErrTee(PrintStream printStream, FileOutputStream fileOutputStream){
        this.streamsToConsoleToFile = new OutputStream[2];
        streamsToConsoleToFile[0] = printStream;
        streamsToConsoleToFile[1] = fileOutputStream;
    }

    public StdOutStdErrTee(String stdOutFilePath, String stdErrFilePath){
        this.stdOutFilePath = stdOutFilePath;
        this.stdErrFilePath = stdErrFilePath;
    }

    //
    // Instance Methods
    //

    public void startLog() {
        try{
            FileOutputStream stdOutFile = new FileOutputStream(new File(this.stdOutFilePath));
            FileOutputStream stdErrFile = new FileOutputStream(new File(this.stdErrFilePath));

            StdOutStdErrTee allStdOut = new StdOutStdErrTee(System.out, stdOutFile);
            StdOutStdErrTee allStdErr = new StdOutStdErrTee(System.out, stdErrFile);

            PrintStream stdOut = new PrintStream(allStdOut);
            PrintStream stdErr = new PrintStream(allStdErr);

            System.setOut(stdOut);
            System.setErr(stdErr);

        } catch (FileNotFoundException){
            System.out.println(exception.getMessage());
        }
    }

    public static void stopLog() {

    }

    //
    // Additional Methods
    //

    //
    // Language
    //

    //
    // Override
    //
    @Override
    public void write(int b) throws IOException {
        for (OutputStream out : this.streamsToConsoleToFile){
            out.write(b);
            out.flush();
        }
    }
}