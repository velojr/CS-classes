/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Club.java
 * Author: Juan Segura Rico
 * **********************************************
 */

package assignment02PartB;

import java.util.ArrayList;
import java.util.Arrays;

public final class Club extends Organization {

    private int yearEstablished;
    private ArrayList<String> owners;
    private ArrayList<String> colors;
    private String OfficialName;
    private String Ballpark;
    private int WorldSeriesTitles;
    private int NLPennants;
    private int DivisionTitles;
    private int WildCardBerths;
    private Manager manager;
    private GeneralManager generalManager;
    private President presidentOfBaseballOperations;
    private ArrayList<Player> players;

    public Club() {
    }

    public Club(int yearEstablished, String[] owners, String[] colors, String OfficialName, String Ballpark,
                int WorldSeriesTitles, int NLPennants, int DivisionTitles, int WildCardBerths, Manager manager, GeneralManager generalManager,
                President presidentOfBaseballOperations) {

        this.yearEstablished = yearEstablished;
        this.owners = new ArrayList<>(Arrays.asList(owners));
        this.colors = new ArrayList<>(Arrays.asList(colors));
        this.OfficialName = OfficialName;
        this.Ballpark = Ballpark;
        this.WorldSeriesTitles = WorldSeriesTitles;
        this.NLPennants = NLPennants;
        this.DivisionTitles = DivisionTitles;
        this.WildCardBerths = WildCardBerths;
        this.manager = manager;
        this.generalManager = generalManager;
        this.presidentOfBaseballOperations = presidentOfBaseballOperations;
    }

    public ArrayList<Player> getPlayers() {
        return this.players;
    }

    public String getCurrentOfficialName() {
        return OfficialName;
    }

    public void addPlayers(Player[] players) {
        this.players = new ArrayList<>(Arrays.asList(players));
    }

    public void listPlayers() {
        System.out.println("Players:");
        this.players.forEach((player) -> {
            System.out.println(player + " ");
        });
    }

    private Object returnArrayListAsString(ArrayList<String> arrayList) {
        StringBuilder returnString = new StringBuilder(arrayList.toString());
        returnString.deleteCharAt(0);
        returnString.deleteCharAt(returnString.length() - 1);
        return returnString;
    }}

        //
    // Static Methods
    //

    //
    // Instance Methods
    //

    //
    // Additional Instance Methods
    //

    //
    // Language
    //