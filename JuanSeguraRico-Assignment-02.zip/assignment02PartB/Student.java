/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Student.java
 * Author: Juan Segura Rico
 * **********************************************
 */

package assignment02PartB;

import java.util.ArrayList;

public final class Student extends Person {

    //
    // Instance Data Fields
    //

    private String name;

    //
    // Constructors
    //
    public Student() {
        this.name = "Juan";
    }

    public Student(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void sayGreeting(String string) {

    }

    //
    // Instance Methods
    //

    //
    // Additional Methods
    //

    //
    // Language
    //

    //
    // Override
    //
}