/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: FrontOffice.java
 * Author: Juan Segura Rico
 * **********************************************
 */

package assignment02PartB;

public final class FrontOffice {

    //
    // Instance Data Fields
    //

    //
    // Constructors
    //
    public FrontOffice() {
    }

    public FrontOffice(String firstName, String lastName, Club baseballClub) {
        super(firstName, lastName);
        this.club = baseballClub;
    }

    //
    // Instance Methods
    //

    //
    // Language
    //
}