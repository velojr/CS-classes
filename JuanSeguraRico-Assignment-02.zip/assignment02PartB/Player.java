/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Player.java
 * Author: Juan Segura Rico
 * **********************************************
 */

package assignment02PartB;
// Please organize all the given files in 1 same package
// Please make sure to read the provided "_ListOf-PleaseDoNotChange.txt"

public final class Player extends Person {

    // Instance Data Fields

    //
    // Constructors
    //
    public Player(String firstName, String lastName, int playerNumber, String position, String bats, String _throws, int debut, Club club) {


    }
}

//
// Instance Methods
//

//
// Additional Instance Methods
//

//
// Language
//
