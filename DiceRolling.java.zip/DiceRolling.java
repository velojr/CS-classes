/*
 * Assignment 2
 * Dice Roll
 * Juan Segura Rico
 * 921725126
 * CSC 210-01
 * Fall 2021
 */

import java.util.Scanner;
public class DiceRolling {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int myRandomInt;

        // This will roll a random number between 1 and 6.
        myRandomInt = (int) (Math.random() * 6 + 1);

        System.out.println("I got " + myRandomInt);

        if (myRandomInt == 1)
            System.out.println("This is an odd number");

        if (myRandomInt == 1)
            System.out.println("This is not divisible by 3");

        if (myRandomInt == 2)
            System.out.println("This is an even number");

        if (myRandomInt == 2)
            System.out.println("This is not divisible by 3");

        if (myRandomInt == 3)
            System.out.println("This is an odd number");

        if (myRandomInt == 3)
            System.out.println("This is divisible by 3");

        if (myRandomInt == 4)
            System.out.println("This is an even number");

        if (myRandomInt == 4)
            System.out.println("This is not divisible by 3");

        if (myRandomInt == 5)
            System.out.println("This is an odd number");

        if (myRandomInt == 5)
            System.out.println("This is not divisible by 3");

        if (myRandomInt == 6)
            System.out.println("This is an even number");

        if (myRandomInt == 6)
            System.out.println("This is divisible by 3");
    }
}

