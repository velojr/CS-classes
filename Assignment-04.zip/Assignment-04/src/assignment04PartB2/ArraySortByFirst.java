package assignment04PartB2;
/**
 *
 * Part B.2
 *
 * Please do not change any code in the main method
 *
 */
public class ArraySortByFirst
{
    public static void sortByFirst(int data[][])
    {
        int Smallest;
        for (int i = 0; i < data.length - 1; i++) {
            Smallest = getSmallest(data, i, data.length - 1);
            swap(data, i, Smallest);
        }
    }

    private static int getSmallest(int[][] a, int first, int last)
    {
        int min = a[first][0];
        int indexOfMin = first;
        for (int i = first + 1; i <= last; i++) {
            if (a[i][0] < min) {
                min = a[i][0];
                indexOfMin = i;
            }
        }
        return indexOfMin;
    }

    private static void swap(int[][] a, int i, int j)
    {
        int x;
        for (int k = 0; k < a[i].length; k++) {
            x = a[i][k];
            a[i][k] = a[j][k];
            a[j][k] = x;
        }
    }

    public static void display(int data[][])
    {
        for (int[] data1 : data) {
            System.out.print("   ");
            for (int i = 0; i < data[0].length; i++) {
                System.out.printf("%3d", data1[i]);
            }
            System.out.println();
        }
    }

    //
    // Please do not change any code in the main method
    //
    public static void main(String args[])
    {
        int array[][] = {{1, 2, 3, 4, 5},
                {3, 4, 5, 1, 2},
                {5, 2, 3, 4, 1},
                {2, 3, 1, 4, 5},
                {4, 2, 3, 1, 5}};

        System.out.println("The array is initially " );
        display(array);
        System.out.println();

        sortByFirst(array);
        System.out.println("The array after sorting is " );
        display(array);
        System.out.println();
    }
}