package assignment04PartD;

public class CircularDoublyLinkedDeque<T> implements DequeInterface<T> {

    private DoublyLinkedNode firstNode;

    public CircularDoublyLinkedDeque()
    {
        firstNode = null;
    }

    public void addToBack(T newEntry)
    {
        DoublyLinkedNode newNode = new DoublyLinkedNode(newEntry);
        if (firstNode == null) {
            newNode.next = newNode;
            newNode.previous = newNode;
            firstNode = newNode;
        }
        else {
            DoublyLinkedNode previousNode = firstNode.previous;
            previousNode.next = newNode;
            firstNode.previous = newNode;
            newNode.previous = previousNode;
            newNode.next = firstNode;
        }
    }

    public void addToFront(T newEntry)
    {
        DoublyLinkedNode newNode = new DoublyLinkedNode(newEntry);
        if (firstNode == null) {
            newNode.next = newNode;
            newNode.previous = newNode;
            firstNode = newNode;
        }
        else {
            DoublyLinkedNode previousNode = firstNode.previous;
            previousNode.next = newNode;
            firstNode.previous = newNode;
            newNode.previous = previousNode;
            newNode.next = firstNode;
            firstNode = newNode;
        }
    }

    public T getFront()
    {
        return firstNode.data;
    }

    public T getBack()
    {
        return firstNode.previous.data;
    }

    public T removeFront()
    {
        if (firstNode == null) {
            throw new EmptyQueueException();
        }
        else {
            DoublyLinkedNode frontNode = firstNode.next;
            DoublyLinkedNode backNode = firstNode.previous;
            T firstNodeData = firstNode.data;
            frontNode.previous = backNode;
            backNode.next = frontNode;
            firstNode = frontNode;
            return firstNodeData;
        }
    }

    public T removeBack()
    {
        if (firstNode == null) {
            throw new EmptyQueueException();
        }
        else {
            DoublyLinkedNode previousNode = firstNode.previous.previous;
            T backNodeData = firstNode.previous.data;
            previousNode.next = firstNode;
            firstNode.previous = previousNode;
            return backNodeData;
        }
    }

    public void clear()
    {
        firstNode = null;
    }

    public boolean isEmpty()
    {
        return firstNode == null;
    }


    private class DoublyLinkedNode
    {
        private T data;
        private DoublyLinkedNode next;
        private DoublyLinkedNode previous;

        private DoublyLinkedNode()
        {
            this(null, null, null);
        }

        private DoublyLinkedNode(T dataPortion)
        {
            this(null, dataPortion, null);
        }

        private DoublyLinkedNode(DoublyLinkedNode previousNode, T dataPortion, DoublyLinkedNode nextNode)
        {
            data = dataPortion;
            next = nextNode;
            previous = previousNode;
        }

        private T getData()
        {
            return data;
        }

        private void setData(T newData)
        {
            data = newData;
        }

        private DoublyLinkedNode getNextNode()
        {
            return next;
        }

        private void setNextNode(DoublyLinkedNode nextNode)
        {
            next = nextNode;
        }

        private DoublyLinkedNode getPreviousNode()
        {
            return previous;
        }

        private void setPreviousNode(DoublyLinkedNode previousNode)
        {
            previous = previousNode;
        }
    }

} // end CircularDoublyLinkedDeque