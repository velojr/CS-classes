package assignment04PartE;

/**
 * Part E
 */

import java.util.PriorityQueue;
import java.util.Queue;

public final class Student implements Comparable<Student> {
    private String firstName;
    private String lastName;
    private int ID;
    private int SQ;
    private int BQ;
    private double GPA;
    private static String priority;

    public Student(String firstName, String lastName, int ID, double GPA, int SQ, int BQ) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.ID = ID;
        this.SQ = SQ;
        this.BQ = BQ;
        this.GPA = GPA;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getID() {
        return ID;
    }

    public double getGPA() {
        return GPA;
    }

    public int getBQ() {
        return BQ;
    }

    public int getSQ() {
        return SQ;
    }

    public static String[] getPriorities() {
        String[] Priorities = {"realistic (provided by supervisors)", "first-name", "last-name", "student-id", "gpa",
                "number-of-small-questions", "number-of-big-questions", "number of small-and-big questions"};
        return Priorities;
    }

    public static void setCompareToPriority(String CtoPriority) {
        priority = CtoPriority;
    }

    @Override
    public String toString() {
        return this.firstName + "  " + this.lastName + "  " + this.ID + "  " + this.GPA + "  " + this.SQ + "  " + this.BQ;
    }

    @Override
    public int compareTo(Student student) {
        String firstName = student.getFirstName();
        String lastName = student.getLastName();
        int ID = student.getID();
        int SQ = student.getSQ();
        int BQ = student.getBQ();
        double GPA = student.getGPA();

        // sorting first name with if statements
        if (priority.equals("first-name")) {
            return this.getFirstName().compareTo(firstName);
        }
        // last name if statements
        if (priority.equals("last-name")) {
            if (this.getLastName().equals(lastName)) {
                return this.getFirstName().compareTo(lastName);
            }
            return this.getLastName().compareTo(lastName);
        }

        // sorting gpa with ID with if statements
        if (priority.equals("student-id")) {
            if (this.getID() < ID) {
                return -1;
            } else {
                return 1;
            }
        }

        // sorting GPA
        if (priority.equals("gpa")) {
            if (this.getGPA() < GPA) {
                return -1;
            } else if (this.getGPA() > GPA) {
                return 1;
            } else if (this.getGPA() == GPA) {
                return this.getFirstName().compareTo(firstName);
            }
        }

        // sorting small questions
        if (priority.equals("number-of-small-questions")) {
            if (this.getSQ() < SQ) {
                return 1;
            } else if (this.getSQ() > SQ) {
                return -1;
            } else {
                return this.getFirstName().compareTo(firstName);
            }
        }
        // sorting big questions
        if (priority.equals("number-of-big-questions")) {
            if (this.getBQ() < BQ) {
                return -1;
            } else if (this.getBQ() > BQ) {
                return 1;
            } else {
                return this.getFirstName().compareTo(firstName);
            }
        }
        if (priority.equals("number of small-and-big questions")) {
            if (this.getBQ() + this.getSQ() < SQ + BQ) {
                return -1;
            } else if (this.getBQ() + this.getSQ() > SQ + BQ) {
                return 1;
            } else if (this.getBQ() + this.getSQ() == SQ + BQ) {
                if (SQ + BQ < 20) {
                    return this.getLastName().compareTo(lastName);
                }

            } else {
                return this.getFirstName().compareTo(firstName);
            }
        }
        // realistic sorting
        if (priority.equals("realistic (provided by supervisors)")) {
            if (this.getLastName().substring(this.getLastName().length() - 1).equals(lastName.substring(lastName.length() - 1))) {
                if (this.getLastName().contains("u")) {
                    if (this.getID() < ID) {
                        return -1;
                    } else {
                        return 1;
                    }
                }
                return this.getFirstName().compareTo(firstName);
            } else {
                return this.getLastName().substring(this.getLastName().length() - 1).compareTo(lastName.substring(lastName.length() - 1));
            }
        }
        return 0;
    }
}

