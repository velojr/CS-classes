package assignment04PartE;

/**
 *
 * Part E
 *
 */

import java.util.PriorityQueue;

public class SFSUOneStop {

    public static void display(PriorityQueue<Student> oneStopPQ, String priority) {
        System.out.println("Priority: " + priority);

        while (oneStopPQ.peek() != null) {
            System.out.println(oneStopPQ.poll());
        }
    }
}