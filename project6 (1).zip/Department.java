public class Department {
    private static String name;
    private int students;
    private int count;

    public Department(int students, int count) {
        this.students = students;
        this.count = count;
    }

    public static void setName(String name) {
        Department.name = name;
    }

    public int getStudents() {
        return students;
    }

    public int getCount() {
        return count;
    }

    public static void getName(String name) {
        name = "Department";
    }

    public int setStudents() {
        return students;
    }

    public int setCount() {
        return count;
    }

    public String toString() {
        return name + students + count;
    }

    public static void main (String args[]) {
        System.out.println("");
    }
}
