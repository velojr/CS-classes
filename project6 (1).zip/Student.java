/*
 * Project 6
 * Student.java
 * Juan Segura Rico
 * 921725126
 * CSC 210-01
 * Fall 2021
 */

public class Student {
    private int studentID;
    private static String name;
    private String email;
    private String majorDepartment;

    public Student(int studentID, String name, String email, String majorDepartment) {
        this.studentID = studentID;
        this.name = name;
        this.email = email;
        this.majorDepartment = majorDepartment;
    }

    public String toString() {

        this.studentID = 12345678;

        this.name = "Jack";

        this.email = "jack_email_19@gmail.com";

        this.majorDepartment = "Computer Science Department";

        return studentID + name + email + majorDepartment;
    }

    public int getStudentID () {
        return this.studentID;
    }

    public String getName () {
        return this.name;
    }

    public String getEmail () {
        return this.email;
    }

    public String getMajorDepartment () {
        return this.majorDepartment;
    }


    public static void main (String [] args) {
        System.out.println("We have a new Student, his name is " + name);

    }
}


